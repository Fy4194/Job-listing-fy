import './job-card.scss';
