import '../attribution/attribution';
import './footer.scss';
